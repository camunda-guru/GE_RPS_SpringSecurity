package com.ust.bookstore.entities;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BookCostValidator implements ConstraintValidator<BookCost, Integer> {

	@Override
    public void initialize(BookCost cost) { }
 
    @Override
    public boolean isValid(Integer bookCost, ConstraintValidatorContext cxt) {
        if(bookCost <= 10) {
            return false;
        }
        return bookCost >10;
    }

	
}
