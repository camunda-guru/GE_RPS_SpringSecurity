package com.ust.bookstore;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ust.bookstore.entities.UserAccount;
import com.ust.bookstore.service.LoginService;


/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
@Autowired
private LoginService loginService;
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String registration(Map<String, Object> map) {
		map.put("useraccount", new UserAccount());
		
		return "register";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addContact(@Valid@ModelAttribute("useraccount")  UserAccount useraccount,BindingResult result) {
		if(result.hasErrors()) {
			
			
            return "register";
        }
		else
		{	
 
        loginService.AddUserService(useraccount);
          
        return "redirect:../bookstore";
		}
    }
 
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value="/success",method=RequestMethod.GET)
	public String LoginHandler(@ModelAttribute UserAccount useracct,ModelMap model)
	{
		
		//boolean result = loginService.LoginValidationService(useracct);
		//System.out.println(user.getUsername());
		User user1 = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String name = user1.getUsername();
	
		model.addAttribute("info", name);
		model.addAttribute("message", "Spring Security login + database example");
		// model.addAttribute("info",user.getUsername());
		//if(result)		
		  
		  return "/success";
		
		//else
		//	return "redirect:../bookstore";
		
	
	}
	
}
