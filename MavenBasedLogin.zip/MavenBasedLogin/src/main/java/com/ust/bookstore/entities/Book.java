package com.ust.bookstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Book")
public class Book {
	@Id
	@GeneratedValue
	@Column(name="Bookid")
	private String bookId;
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getBookType() {
		return bookType;
	}
	public void setBookType(String bookType) {
		this.bookType = bookType;
	}
	@NotEmpty
	@Column(name="BookName")
	private String bookName;
    @BookCost(message="Cost cannot be less than 10")
	@Column(name="Cost")
	private int cost;
	@NotEmpty
	@Column(name="BookType")
	private String bookType;

}
