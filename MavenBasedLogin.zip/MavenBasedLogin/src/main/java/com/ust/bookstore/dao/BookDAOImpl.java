package com.ust.bookstore.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ust.bookstore.entities.Book;
@Repository
public class BookDAOImpl implements BookDAO{
@Autowired
private SessionFactory sessionfact;
	@Override
	public void AddBookDAO(Book book) {
		sessionfact.getCurrentSession().saveOrUpdate(book);
		
	}
	@Override
	public List<Book> BookListDAO() {
		
		return (List<Book>) sessionfact.getCurrentSession().createCriteria(Book.class).list();
	}

}
