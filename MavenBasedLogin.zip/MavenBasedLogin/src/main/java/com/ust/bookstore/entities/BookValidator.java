package com.ust.bookstore.entities;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
@Component
public class BookValidator implements Validator {

	 private final static String Book_COST = "cost";  
	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Book.class.isAssignableFrom(clazz);  
	}

	@Override
	public void validate(Object target, Errors errors) {
		Book  book = (Book) target;  
		         
		       Integer cost = book.getCost();		          
		      
		        if (cost < 10)  
	            errors.rejectValue(Book_COST, "book.cost.less than Ten");  
	  

		
	}

}
