package com.ust.bookstore.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ust.bookstore.entities.UserAccount;
@Repository
public class LoginDAOImpl implements LoginDAO {
@Autowired
private SessionFactory sessionfactory;

	@Override
	public boolean LoginValidation(UserAccount useraccount) {
		boolean status=false;
		System.out.println(useraccount.getFirstName());
		Query query =sessionfactory.getCurrentSession().createQuery("from UserAccount where firstname=:name and password=:pwd");
		query.setParameter("name", useraccount.getFirstName());
		query.setParameter("pwd", useraccount.getPassword());
		List<UserAccount> userlist = query.list();
		for(UserAccount udata:userlist)
		{
			System.out.println(udata.getFirstName());
			System.out.println(useraccount.getFirstName());
			if(udata.getFirstName().equals(useraccount.getFirstName()))
				status=true;
		}
		return status;
	}

	@Override
	public void AddUser(UserAccount useraccount) {
		sessionfactory.getCurrentSession().saveOrUpdate(useraccount);
		
	}

}
