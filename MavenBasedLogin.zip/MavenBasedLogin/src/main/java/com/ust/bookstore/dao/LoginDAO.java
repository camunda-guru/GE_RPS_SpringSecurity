package com.ust.bookstore.dao;

import com.ust.bookstore.entities.UserAccount;

public interface LoginDAO {
    
	public void AddUser(UserAccount useraccount);
	public boolean LoginValidation(UserAccount useraccount);
	
}
