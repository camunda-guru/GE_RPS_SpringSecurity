package com.ust.bookstore;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ust.bookstore.entities.Book;
import com.ust.bookstore.entities.BookValidator;
import com.ust.bookstore.entities.UserAccount;
import com.ust.bookstore.service.BookService;

@Controller
public class BookController {
@Autowired
private BookService bookservice;


	@RequestMapping(value = "/addbook", method = RequestMethod.GET)
	public String registration(Map<String, Object> map) {
		map.put("book", new Book());
		
		return "addbook";
	}
	
	@RequestMapping(value = "/booklist", method = RequestMethod.GET)
	public String booklisthandler(@ModelAttribute Book book,ModelMap model) {
		
		List<Book> result = bookservice.BookListService();
		for(Book bookdata:result)
			System.out.println(bookdata.getBookName());
		
		model.addAttribute("books",result);
		return "booklist";
	}
	
	@RequestMapping(value = "/storebook", method = RequestMethod.POST)
    public String addContact(@Valid @ModelAttribute("book") Book book,BindingResult result) {
		if(result.hasErrors()) {
			
			System.out.println(result.getFieldError("cost"));
            return "addbook";
        }
		else
		{	
 
        bookservice.AddBookService(book);
          
        return "redirect:../bookstore/booklist";
		}
    }
}
