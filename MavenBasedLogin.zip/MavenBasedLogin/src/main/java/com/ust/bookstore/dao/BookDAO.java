package com.ust.bookstore.dao;

import java.util.List;

import com.ust.bookstore.entities.Book;

public interface BookDAO {

	public void AddBookDAO(Book book);
	public List<Book> BookListDAO();
	
}
