package com.ust.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ust.bookstore.dao.LoginDAO;
import com.ust.bookstore.entities.UserAccount;
@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class LoginServiceImpl implements LoginService{
@Autowired
private LoginDAO loginDAO;
	@Override
	public boolean LoginValidationService(UserAccount useraccount) {
		// TODO Auto-generated method stub
		return loginDAO.LoginValidation(useraccount);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public void AddUserService(UserAccount useraccount) {
		loginDAO.AddUser(useraccount);
		
	}

}
