package com.ust.bookstore.service;

import com.ust.bookstore.entities.UserAccount;

public interface LoginService {
    
	public void AddUserService(UserAccount useraccount);
	public boolean LoginValidationService(UserAccount useraccount);
	
}
