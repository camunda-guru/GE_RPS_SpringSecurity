package com.ust.bookstore.service;

import java.util.List;

import com.ust.bookstore.entities.Book;

public interface BookService {

	public void AddBookService(Book book);
	public List<Book> BookListService();
}
